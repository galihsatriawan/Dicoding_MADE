package id.shobrun.moviecatalogue.view;

import id.shobrun.moviecatalogue.model.DetailMovieModel;

public interface DetailMovieView extends RootView {
    public void showDetailMovie(DetailMovieModel model);
}
