package id.shobrun.moviecatalogue.view;

public interface RootView {
    void showActionBar();
}
