package id.shobrun.moviecatalogue.utils.common;

import android.view.View;

public interface OnItemClickListener {
    void onItemClicked(View v, int position);
}
