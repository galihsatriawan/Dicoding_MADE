package id.shobrun.moviecatalogue.views.iview;

public interface IConsumerMainView extends IRootView{
}
