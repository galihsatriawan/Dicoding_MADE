package id.shobrun.moviecatalogue.views.iview;

public interface IRootView {
    void showActionBar();
}
