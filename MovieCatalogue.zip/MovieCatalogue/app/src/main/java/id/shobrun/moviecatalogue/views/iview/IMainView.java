package id.shobrun.moviecatalogue.views.iview;

public interface IMainView extends IRootView {
    void showTabLayout();
}
