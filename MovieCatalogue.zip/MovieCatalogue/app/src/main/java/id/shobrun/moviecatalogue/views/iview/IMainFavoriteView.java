package id.shobrun.moviecatalogue.views.iview;

public interface IMainFavoriteView extends IRootView{
    void showTabLayout();
}
