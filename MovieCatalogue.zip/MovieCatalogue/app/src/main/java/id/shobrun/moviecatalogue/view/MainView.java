package id.shobrun.moviecatalogue.view;

import id.shobrun.moviecatalogue.model.MainModel;

public interface MainView extends RootView {
    void showListMovieCatalogue(MainModel model);
}
