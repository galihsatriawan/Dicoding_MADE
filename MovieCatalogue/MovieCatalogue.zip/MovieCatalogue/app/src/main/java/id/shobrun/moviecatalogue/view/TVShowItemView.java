package id.shobrun.moviecatalogue.view;


public interface TVShowItemView {
    void setPoster(int poster);
    void setNotification(int notif);
}
