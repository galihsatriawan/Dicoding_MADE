package id.shobrun.moviecatalogue.component.common;

import android.view.View;

public interface OnItemClickListener {
    void onItemClicked(View v, int position);
}
