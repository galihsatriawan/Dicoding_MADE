package id.shobrun.moviecatalogue.component.common;

import android.view.View;

public interface OnViewClickListener {
    void onViewClicked(View view);
    void onViewClicked(View v1,View v2);
}
