package id.shobrun.moviecatalogue.view;

import id.shobrun.moviecatalogue.model.MovieModel;

public interface TvShowView {
    void showListTvShow(MovieModel model);
}
