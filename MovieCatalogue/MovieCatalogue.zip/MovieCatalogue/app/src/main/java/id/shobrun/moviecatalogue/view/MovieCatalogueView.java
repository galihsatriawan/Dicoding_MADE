package id.shobrun.moviecatalogue.view;

import id.shobrun.moviecatalogue.model.MovieModel;

public interface MovieCatalogueView {
    void showListMovieCatalogue(MovieModel model);
    void showDetailMovie();
}
