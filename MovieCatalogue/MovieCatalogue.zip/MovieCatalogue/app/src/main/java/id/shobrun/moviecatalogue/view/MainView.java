package id.shobrun.moviecatalogue.view;


public interface MainView extends RootView {
    void showTabLayout();

}
